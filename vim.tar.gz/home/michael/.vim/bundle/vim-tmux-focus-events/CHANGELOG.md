# Changelog

### master

### v1.0.0, 2015-03-21
- first working version
- do not run outside tmux or in gui vim
- copy and adapt FocusGained, FocusLost event triggering from
  https://github.com/sjl/vitality.vim
- rename plugin to 'vim-tmux-focus-events'
- add README
- add the list of terminals where the plugin was tested and works
- don't help `autoread` if it is not set
